import React, { Component } from 'react';
import './App.css';
import Containers from './containers/containers';
import Button from './components/Button';
import TextInput from './components/TextInput';



class App extends Component {

  state = {
    score: '',
    grade: '' 
  }
  
  ihputChangeHandler = (event) =>{
    let value = event.target.value;
    this.setState({
      score: value
    });
    console.log("Hello");

  }

  calculateGradeHandler = () => {
    let score = this.state.score;
    let grade = '';
    if(score >= 80){
      grade = 'A'
    } else{
      grade = 'S'
    }
    this.setState({
      grade: grade
    });
    // alert("asdasd")
    // console.log("asdasd");
    // this.state.grade = grade;
    // console.log(this.state.grade);

}

  Button
  render(){
    return(
      // TextInput
      <Containers>
<       div className="App">
          <div class="input-group mb-3">
            <TextInput value={this.state.score} classes="form-control" placeholder="input your score" change={this.ihputChangeHandler} />
            <div className="input-group-prepend">
            <Button classes= "btn btn-outline-secondary" click={this.calculateGradeHandler }> Click </Button>
            </div>
          </div>
        </div>
        <h1> Grade : {this.state.grade} </h1>
      </Containers>
    )
  }
}


export default App;
