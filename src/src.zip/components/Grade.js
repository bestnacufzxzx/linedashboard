import React, { Component } from 'react';

export default class Grade extends Component {
    render(){
        return(
            <div>
                
            </div>
        )
    }
}